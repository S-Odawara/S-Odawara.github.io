$(document).ready(function(){
    $("#nav-button").on("click", function(){
        $(".sp-nav").slideToggle();
    });
});
